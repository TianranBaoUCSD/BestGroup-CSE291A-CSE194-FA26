# Bay Area Housing & Demographics Explorer (CSE 194)

Explore how housing prices and demographics changed across the nine Bay Area
counties and their subdivisions from 2000 to 2026.

```
cse194/
├── frontend/   React (Vite) + Leaflet map, year slider, Housing/Demographics switch
└── backend/    FastAPI service that serves metrics by region and year
```

## Run it

**1. Backend** (Python 3.10+)

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload --port 8000
```

**2. Frontend** (Node 18+), in a second terminal

```bash
cd frontend
npm install
npm run dev          # http://localhost:5173
```

The frontend proxies `/api/*` to `localhost:8000`, so start the backend first.
Without it the map still works; it just isn't shaded.

**3. Load real data** (needs internet; run from the project root)

```bash
python backend/scripts/build_data.py
```

This downloads official Census boundaries (counties + county subdivisions)
into `frontend/public/data/` and ACS / Decennial Census figures into
`backend/data/metrics.csv`. Then restart the backend (or `curl -X POST
localhost:8000/api/reload`).

> The `subdivisions.geojson` that ships with the repo is a **placeholder**:
> real county outlines split into approximate subdivisions with hand-drawn
> lines. The script above replaces it with the Census Bureau's official
> county subdivisions, whose IDs match the data.

## Database (PostgreSQL)

Production data lives in PostgreSQL. The schema is defined with SQLAlchemy in
`backend/app/db/models.py` and created by Alembic migrations in
`backend/migrations/`.

| Table | Holds |
| --- | --- |
| `regions` | each county (5-digit GEOID) and county subdivision (10-digit GEOID), with its parent county |
| `metrics` | the catalog of measures (`median_home_value`, `population`, …) and which dataset they belong to |
| `metric_values` | one value per region × metric × year, plus its source (`acs5`, `dec2000`) |

**Start a local database and create the tables**

```bash
cp .env.example .env                 # set POSTGRES_PASSWORD (and DATABASE_URL to match)
docker compose up -d db
cd backend && source .venv/bin/activate
pip install -r requirements-dev.txt
set -a && source ../.env && set +a   # export DATABASE_URL
alembic upgrade head
```

**Run the whole stack in Docker:** `docker compose up -d --build` (the API
container applies migrations on start).

**Managed Postgres in production:** set `DATABASE_URL` to the provider's
connection string (`postgresql+psycopg://…?sslmode=require`) and run
`alembic upgrade head` once per deploy.

**Changing the schema:** edit `models.py`, then
`alembic revision --autogenerate -m "describe change"` and review the file it writes.

> The API still reads `backend/data/metrics.csv`; the endpoints haven't been
> switched over to query Postgres yet.

## API

| Endpoint | What it returns |
| --- | --- |
| `GET /api/health` | status + which years have data |
| `GET /api/metadata` | datasets, metrics, year range |
| `GET /api/metrics?dataset=housing&year=2015` | every region's values for that dataset, using the nearest year with data, plus a color-scale domain per metric |
| `GET /api/series?geoid=0600190000&metric=median_home_value` | one region over time |
| `POST /api/reload` | re-read `metrics.csv` |

Tests: `cd backend && pytest`

## Map heatmap

* **Housing** is shaded red (light → dark red = low → high).
* **Demographics** is shaded in cappuccino browns.
* Pick which metric drives the colors from the legend in the map's lower-left corner.
* The color scale is fixed across all years, so playing the timeline shows real change.
