import importlib

import pytest
from fastapi.testclient import TestClient

CSV = """geoid,year,metric,value
0600190000,2015,median_home_value,700000
0600190001,2015,median_home_value,900000
0600190000,2020,median_home_value,950000
06001,2020,median_home_value,1000000
0600190000,2020,population,50000
"""


@pytest.fixture()
def client(tmp_path, monkeypatch):
    path = tmp_path / "metrics.csv"
    path.write_text(CSV)
    monkeypatch.setenv("METRICS_CSV", str(path))
    import app.main as main

    importlib.reload(main)
    return TestClient(main.app)


def test_exact_year(client):
    body = client.get("/api/metrics", params={"dataset": "housing", "year": 2020}).json()
    assert body["data_year"] == 2020
    assert body["values"]["06001"]["median_home_value"] == 1000000
    assert "population" not in body["values"]["0600190000"]  # demographics excluded


def test_nearest_earlier_year(client):
    body = client.get("/api/metrics", params={"dataset": "housing", "year": 2018}).json()
    assert body["data_year"] == 2015


def test_before_first_year_uses_earliest(client):
    assert client.get("/api/metrics", params={"year": 2003}).json()["data_year"] == 2015


def test_domain_uses_subdivisions_only(client):
    lo, hi = client.get("/api/metrics", params={"year": 2020}).json()["domains"]["median_home_value"]
    assert 700000 <= lo < hi <= 950000


def test_unknown_dataset(client):
    assert client.get("/api/metrics", params={"dataset": "nope", "year": 2020}).status_code == 404


def test_series(client):
    pts = client.get("/api/series", params={"geoid": "0600190000", "metric": "median_home_value"}).json()["points"]
    assert [p["year"] for p in pts] == [2015, 2020]
