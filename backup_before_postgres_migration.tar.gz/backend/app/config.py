"""Settings read from environment variables (see ../.env.example)."""

from __future__ import annotations

import os
from dataclasses import dataclass


def _int(name: str, default: int) -> int:
    return int(os.environ.get(name, default))


@dataclass(frozen=True)
class Settings:
    # e.g. postgresql+psycopg://bayarea:secret@localhost:5432/bayarea
    database_url: str = os.environ.get(
        "DATABASE_URL", "postgresql+psycopg://bayarea:bayarea@localhost:5432/bayarea"
    )
    db_pool_size: int = _int("DB_POOL_SIZE", 5)
    db_max_overflow: int = _int("DB_MAX_OVERFLOW", 10)
    db_pool_recycle_s: int = _int("DB_POOL_RECYCLE_S", 1800)
    db_echo: bool = os.environ.get("DB_ECHO", "false").lower() == "true"


settings = Settings()
