"""Database schema.

  regions        one row per county or county subdivision (Census GEOID)
  metrics        catalog of what we measure (median_home_value, population, …)
  metric_values  the facts: one value per region × metric × year
"""

from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    CheckConstraint,
    DateTime,
    Double,
    Enum,
    ForeignKey,
    Index,
    SmallInteger,
    String,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base


class RegionLevel(str, enum.Enum):
    county = "county"
    subdivision = "subdivision"


class DatasetName(str, enum.Enum):
    housing = "housing"
    demographics = "demographics"


class Region(Base):
    __tablename__ = "regions"

    # 5 digits for a county (06001), 10 for a county subdivision (0600190000)
    geoid: Mapped[str] = mapped_column(String(10), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    level: Mapped[RegionLevel] = mapped_column(Enum(RegionLevel, name="region_level"))
    county_geoid: Mapped[str | None] = mapped_column(
        String(10), ForeignKey("regions.geoid", ondelete="CASCADE"), index=True
    )

    county: Mapped[Region | None] = relationship(remote_side=[geoid], back_populates="subdivisions")
    subdivisions: Mapped[list[Region]] = relationship(back_populates="county")
    values: Mapped[list[MetricValue]] = relationship(back_populates="region")

    __table_args__ = (
        CheckConstraint(
            "(level = 'county' AND county_geoid IS NULL AND length(geoid) = 5)"
            " OR (level = 'subdivision' AND county_geoid IS NOT NULL AND length(geoid) = 10)",
            name="level_matches_geoid",
        ),
    )

    def __repr__(self) -> str:
        return f"<Region {self.geoid} {self.name!r} ({self.level.value})>"


class Metric(Base):
    __tablename__ = "metrics"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)  # e.g. median_home_value
    dataset: Mapped[DatasetName] = mapped_column(Enum(DatasetName, name="dataset_name"), index=True)
    label: Mapped[str] = mapped_column(String(120))
    format: Mapped[str] = mapped_column(String(16))  # usd | pct | int | years

    values: Mapped[list[MetricValue]] = relationship(back_populates="metric")

    def __repr__(self) -> str:
        return f"<Metric {self.key} ({self.dataset.value})>"


class MetricValue(Base):
    __tablename__ = "metric_values"

    geoid: Mapped[str] = mapped_column(
        String(10), ForeignKey("regions.geoid", ondelete="CASCADE"), primary_key=True
    )
    metric_key: Mapped[str] = mapped_column(
        String(64), ForeignKey("metrics.key", ondelete="CASCADE"), primary_key=True
    )
    year: Mapped[int] = mapped_column(SmallInteger, primary_key=True)
    value: Mapped[float] = mapped_column(Double)
    source: Mapped[str | None] = mapped_column(String(32))  # e.g. acs5, dec2000
    loaded_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    region: Mapped[Region] = relationship(back_populates="values")
    metric: Mapped[Metric] = relationship(back_populates="values")

    __table_args__ = (
        CheckConstraint("year BETWEEN 1990 AND 2100", name="year_range"),
        # The map asks for "all regions, one metric, one year".
        Index("ix_metric_values_metric_year", "metric_key", "year"),
    )

    def __repr__(self) -> str:
        return f"<MetricValue {self.geoid} {self.metric_key} {self.year}={self.value}>"
