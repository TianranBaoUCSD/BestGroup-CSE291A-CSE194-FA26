"""FastAPI backend for the Bay Area Housing & Demographics Explorer.

Run from the backend/ folder:
    uvicorn app.main:app --reload --port 8000
"""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from .metrics_config import DATASETS, YEAR_MAX, YEAR_MIN
from .store import MetricStore

DATA_PATH = Path(os.environ.get("METRICS_CSV", Path(__file__).resolve().parent.parent / "data" / "metrics.csv"))

app = FastAPI(title="Bay Area Housing & Demographics API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

store = MetricStore.from_csv(DATA_PATH)


def _dataset(name: str) -> dict:
    if name not in DATASETS:
        raise HTTPException(404, f"Unknown dataset '{name}'. Options: {', '.join(DATASETS)}")
    return DATASETS[name]


@app.get("/api/health")
def health() -> dict:
    return {"status": "ok", "years_loaded": store.years}


@app.get("/api/metadata")
def metadata() -> dict:
    return {"year_min": YEAR_MIN, "year_max": YEAR_MAX, "years_with_data": store.years, "datasets": DATASETS}


@app.get("/api/metrics")
def metrics(
    dataset: str = Query("housing"),
    year: int = Query(..., ge=YEAR_MIN, le=YEAR_MAX),
) -> dict:
    """Every region's values for one dataset, using the nearest year that has data."""
    keys = list(_dataset(dataset)["metrics"])
    data_year = store.nearest_year(year)
    return {
        "dataset": dataset,
        "requested_year": year,
        "data_year": data_year,
        "values": store.values_for(data_year, keys) if data_year is not None else {},
        "domains": {k: store.domain(k) for k in keys},
    }


@app.get("/api/series")
def series(geoid: str, metric: str) -> dict:
    """One region's values over time, e.g. for a line chart."""
    if not any(metric in d["metrics"] for d in DATASETS.values()):
        raise HTTPException(404, f"Unknown metric '{metric}'")
    return {"geoid": geoid, "metric": metric, "points": store.series(geoid, metric)}


@app.post("/api/reload")
def reload() -> dict:
    """Re-read metrics.csv after running scripts/build_data.py."""
    global store
    store = MetricStore.from_csv(DATA_PATH)
    return {"status": "reloaded", "years_loaded": store.years}
