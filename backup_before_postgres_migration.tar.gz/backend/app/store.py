"""In-memory store for metric values, loaded from data/metrics.csv.

CSV format (long / tidy):  geoid,year,metric,value
  geoid  - Census GEOID: 5 digits for a county (06001), 10 for a county subdivision
  year   - data year (e.g. 2022 for the 2018–2022 ACS 5-year estimates)
"""

from __future__ import annotations

import csv
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path


def _percentile(sorted_vals: list[float], q: float) -> float:
    if not sorted_vals:
        raise ValueError("empty")
    k = (len(sorted_vals) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(sorted_vals) - 1)
    return sorted_vals[lo] + (sorted_vals[hi] - sorted_vals[lo]) * (k - lo)


@dataclass
class MetricStore:
    # year -> geoid -> metric -> value
    by_year: dict[int, dict[str, dict[str, float]]] = field(default_factory=dict)
    # metric -> all values across years (sorted), used for a stable color scale
    _all: dict[str, list[float]] = field(default_factory=dict)

    @classmethod
    def from_csv(cls, path: Path) -> "MetricStore":
        by_year: dict[int, dict[str, dict[str, float]]] = defaultdict(lambda: defaultdict(dict))
        all_vals: dict[str, list[float]] = defaultdict(list)
        if path.exists():
            with path.open(newline="") as f:
                for row in csv.DictReader(f):
                    try:
                        year, value = int(row["year"]), float(row["value"])
                    except (KeyError, TypeError, ValueError):
                        continue
                    by_year[year][row["geoid"]][row["metric"]] = value
                    # Only subdivisions (10-digit GEOIDs) are drawn on the map.
                    if len(row["geoid"]) == 10:
                        all_vals[row["metric"]].append(value)
        store = cls({y: {g: dict(m) for g, m in geos.items()} for y, geos in by_year.items()})
        store._all = {m: sorted(v) for m, v in all_vals.items()}
        return store

    @property
    def years(self) -> list[int]:
        return sorted(self.by_year)

    def nearest_year(self, year: int) -> int | None:
        """Latest data year at or before `year`; else the earliest year after it."""
        if not self.by_year:
            return None
        earlier = [y for y in self.years if y <= year]
        return earlier[-1] if earlier else self.years[0]

    def values_for(self, year: int, metrics: list[str]) -> dict[str, dict[str, float]]:
        rows = self.by_year.get(year, {})
        return {
            geoid: {m: vals[m] for m in metrics if m in vals}
            for geoid, vals in rows.items()
            if any(m in vals for m in metrics)
        }

    def domain(self, metric: str) -> list[float] | None:
        """2nd–98th percentile across all years, so colors are comparable over time."""
        vals = self._all.get(metric)
        if not vals:
            return None
        return [_percentile(vals, 0.02), _percentile(vals, 0.98)]

    def series(self, geoid: str, metric: str) -> list[dict]:
        return [
            {"year": y, "value": self.by_year[y][geoid][metric]}
            for y in self.years
            if metric in self.by_year[y].get(geoid, {})
        ]
