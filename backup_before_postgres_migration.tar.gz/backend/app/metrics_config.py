"""Which metrics exist, grouped by dataset. Keys must match frontend/src/constants.js."""

DATASETS: dict[str, dict] = {
    "housing": {
        "label": "Housing",
        "metrics": {
            "median_home_value": {"label": "Median home value", "format": "usd"},
            "median_gross_rent": {"label": "Median gross rent", "format": "usd"},
            "owner_occupied_pct": {"label": "Homeownership rate", "format": "pct"},
            "vacancy_rate_pct": {"label": "Vacancy rate", "format": "pct"},
        },
    },
    "demographics": {
        "label": "Demographics",
        "metrics": {
            "population": {"label": "Population", "format": "int"},
            "median_household_income": {"label": "Median household income", "format": "usd"},
            "median_age": {"label": "Median age", "format": "years"},
            "bachelors_pct": {"label": "Bachelor's degree or higher", "format": "pct"},
        },
    },
}

YEAR_MIN, YEAR_MAX = 2000, 2026
